<x-app-layout>

    <link rel="stylesheet" href="{{ asset('css/crud.css') }}">
    <div class="detail-container">
        <img src="{{ asset('storage/' . $product->foto1) }}" class="detail-image" alt="{{ $product->nama_product }}">

        <h2 class="detail-title">{{ $product->nama_product }}</h2>
        <div class="detail-price">Rp {{ number_format($product->harga, 0, ',', '.') }}</div>
        <p class="detail-description">{{ $product->deskripsi }}</p>

        <div class="btn-group">
            <a href="{{ route('products.index') }}" class="btn-back">← Kembali ke Produk</a>
            <a href="{{ route('cart.add', $product->id) }}" class="btn-add">Tambah ke Keranjang 🛒</a>
        </div>
    </div>
</x-app-layout>