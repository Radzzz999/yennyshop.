@extends('layouts.admin')

@section('title', 'Dashboard Admin')
<link rel="stylesheet" href="{{ asset('css/crudadmin.css') }}">

@section('content')
    <h2>⚡ Dashboard Admin</h2>
    <p>Selamat datang, {{ Auth::user()->name }}!</p>

    <div class="my-4">
        <h4> Daftar Produk</h4>
        <a href="{{ route('admin.products.create') }}" class="btn btn-success mb-3">+ Tambah Produk</a>

        <table class="table table-bordered table-dark text-white">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($products as $i => $product)
                    <tr>
                        <td>{{ $i + 1 }}</td>
                        <td>{{ $product->nama_product }}</td>
                        <td>Rp {{ number_format($product->harga, 0, ',', '.') }}</td>
                        <td>
                            <a href="{{ route('admin.products.show', $product->id) }}" class="text-info">Lihat</a> |
                            <a href="{{ route('admin.products.edit', $product->id) }}" class="text-warning">Edit</a> |
                            <form id="delete-form-{{ $product->id }}" action="{{ route('admin.products.destroy', $product->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="button" class="btn btn-link text-danger p-0 m-0"
                                    onclick="confirmDelete({{ $product->id }}, '{{ e($product->nama_product) }}')">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="4">Tidak ada produk.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection

@push('scripts')
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <script>
        function confirmDelete(productId, productName) {
            Swal.fire({
            title: 'Hapus Produk Ini?',
            html: `<strong>${productName}</strong> akan dihapus secara permanen.`,
            icon: 'warning',
            iconColor: '#f39c12',
            showCancelButton: true,
            confirmButtonText: 'Ya, Hapus Sekarang',
            cancelButtonText: 'Batal',
            reverseButtons: true,
            customClass: {
                confirmButton: 'btn btn-danger me-2',
                cancelButton: 'btn btn-secondary'
            },
            buttonsStyling: false,
            showClass: {
                popup: 'animate__animated animate__fadeInDown'
            },
            hideClass: {
                popup: 'animate__animated animate__fadeOutUp'
            }
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + productId).submit();
                }
            });

        }
    </script>
@endpush
