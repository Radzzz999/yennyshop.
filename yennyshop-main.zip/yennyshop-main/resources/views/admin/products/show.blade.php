@extends('layouts.admin')

@section('title', 'Detail Produk')
<link rel="stylesheet" href="{{ asset('css/show.css') }}">

@section('content')
<div class="detail-container">
    <img src="{{ asset('storage/' . $product->foto1) }}" class="detail-image" alt="{{ $product->nama_product }}">

    <h2 class="detail-title">{{ $product->nama_product }}</h2>
    <div class="detail-price">Rp {{ number_format($product->harga, 0, ',', '.') }}</div>
    <p class="detail-description">{{ $product->deskripsi }}</p>

    <div class="btn-group">
        <a href="{{ route('admin.dashboard') }}" class="btn-admin">← Kembali ke Daftar Produk</a>
        <!-- <a href="{{ route('admin.products.edit', $product->id) }}" class="btn-admin">✏️ Edit Produk</a>
        form action="{{ route('admin.products.destroy', $product->id) }}" method="POST" onsubmit="return confirm('Yakin ingin menghapus produk ini?')">
            @csrf
            @method('DELETE') 
            <button type="submit" class="btn-admin">🗑️ Hapus Produk</button>-->
        </form>
    </div>
</div>
@endsection




