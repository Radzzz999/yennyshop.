@extends('layouts.admin')

@section('title', 'Laporan Pembayaran')

@section('content')
    <h1 class="text-2xl font-bold mb-4">Laporan Pembayaran</h1>

    <table class="min-w-full bg-white border">
        <thead class="bg-gray-100">
            <tr>
                <th class="px-4 py-2 border">No</th>
                <th class="px-4 py-2 border">Nama Pengguna</th>
                <th class="px-4 py-2 border">Total Pembayaran</th>
                <th class="px-4 py-2 border">Metode</th>
                <th class="px-4 py-2 border">Status</th>
                <th class="px-4 py-2 border">Tanggal</th>
            </tr>
        </thead>
        <tbody>
            @foreach($payments as $index => $payment)
                <tr>
                    <td class="border px-4 py-2">{{ $index + 1 }}</td>
                    <td class="border px-4 py-2">{{ $payment->user->name ?? 'N/A' }}</td>
                    <td class="border px-4 py-2">Rp {{ number_format($payment->amount, 0, ',', '.') }}</td>
                    <td class="border px-4 py-2">{{ ucfirst($payment->method) }}</td>
                    <td class="border px-4 py-2">
                        <span class="px-2 py-1 rounded bg-{{ $payment->status == 'success' ? 'green' : 'yellow' }}-200">
                            {{ ucfirst($payment->status) }}
                        </span>
                    </td>
                    <td class="border px-4 py-2">{{ $payment->created_at->format('d M Y H:i') }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
