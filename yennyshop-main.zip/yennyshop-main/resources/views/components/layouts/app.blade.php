<!DOCTYPE html>
<html>
<head><title>Yennyshop</title></head>
<body>
    {{ $slot }}
</body>
</html>