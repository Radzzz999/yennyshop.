<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use App\Models\Payment;


class PaymentController extends Controller
{
    public function show(Request $request)
    {
        $cart = Session::get('cart', []);
        $total = collect($cart)->sum(function ($item) {
            return $item['price'] * $item['quantity'];
        });

        return view('payment.payment', compact('cart', 'total'));
    }

    public function process(Request $request)
{
    $request->validate([
        'payment_method' => 'required|in:qris,bank',
    ]);

    $user = Auth::user();

    // Hitung ulang total dari cart database
    $cartItems = \App\Models\Cart::where('user_id', $user->id)->get();
    $total = $cartItems->sum(function ($item) {
        return $item->product->price * $item->quantity;
    });

    // Simpan ke tabel payments
    Payment::create([
        'user_id' => $user->id,
        'payment_method' => $request->payment_method,
        'amount' => $total,
    ]);

    // Kosongkan keranjang
    \App\Models\Cart::where('user_id', $user->id)->delete();

    return redirect()->route('home')->with('success', 'Pembayaran berhasil!');
}

    
}
