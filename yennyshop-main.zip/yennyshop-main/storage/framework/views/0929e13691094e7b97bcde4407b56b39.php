<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/crud.css')); ?>">

    
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'admin'): ?>
            <a href="<?php echo e(route('products.create')); ?>" class="floating-btn" title="Tambah Produk">➕</a>
        <?php endif; ?>
    <?php endif; ?>

    
    <div class="container mx-auto px-4 py-12 max-w-full overflow-x-hidden">
        <div class="text-center mb-6">
            <h1 class="text-3xl font-bold mb-1">Produk Kami</h1>
            <p class="text-purple-100">Geser ke kanan untuk menjelajahi koleksi produk terbaik!</p>
        </div>

        <div class="product-scroll-container">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="product-card-horizontal">
                    <a href="<?php echo e(route('products.show', $product->id)); ?>">
                        <img src="<?php echo e(asset('storage/' . $product->foto1)); ?>" alt="<?php echo e($product->nama_product); ?>">
                    </a>
                    <div class="product-content">
                        <h2 class="product-title">
                            <a href="<?php echo e(route('products.show', $product->id)); ?>" style="text-decoration: none; color: inherit;">
                                <?php echo e($product->nama_product); ?>

                            </a>
                        </h2>
                        <p class="product-price">Rp <?php echo e(number_format($product->harga, 0, ',', '.')); ?></p>

                        <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST" style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn">Tambah ke Keranjang</button>
                        </form>

                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->role === 'admin'): ?>
                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus produk ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn danger" style="margin-top: 8px;">🗑 Hapus</button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-white px-4">Belum ada produk tersedia.</p>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/products/index.blade.php ENDPATH**/ ?>