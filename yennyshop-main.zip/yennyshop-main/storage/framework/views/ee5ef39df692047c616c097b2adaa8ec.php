<?php $__env->startSection('title', 'Dashboard Admin'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/crudadmin.css')); ?>">

<?php $__env->startSection('content'); ?>
    <h2>⚡ Dashboard Admin</h2>
    <p>Selamat datang, <?php echo e(Auth::user()->name); ?>!</p>

    <div class="my-4">
        <h4> Daftar Produk</h4>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-success mb-3">+ Tambah Produk</a>

        <table class="table table-bordered table-dark text-white">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($i + 1); ?></td>
                        <td><?php echo e($product->nama_product); ?></td>
                        <td>Rp <?php echo e(number_format($product->harga, 0, ',', '.')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.products.show', $product->id)); ?>" class="text-info">Lihat</a> |
                            <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="text-warning">Edit</a> |
                            <form id="delete-form-<?php echo e($product->id); ?>" action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="button" class="btn btn-link text-danger p-0 m-0"
                                    onclick="confirmDelete(<?php echo e($product->id); ?>, '<?php echo e(e($product->nama_product)); ?>')">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4">Tidak ada produk.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <script>
        function confirmDelete(productId, productName) {
            Swal.fire({
            title: 'Hapus Produk Ini?',
            html: `<strong>${productName}</strong> akan dihapus secara permanen.`,
            icon: 'warning',
            iconColor: '#f39c12',
            showCancelButton: true,
            confirmButtonText: 'Ya, Hapus Sekarang',
            cancelButtonText: 'Batal',
            reverseButtons: true,
            customClass: {
                confirmButton: 'btn btn-danger me-2',
                cancelButton: 'btn btn-secondary'
            },
            buttonsStyling: false,
            showClass: {
                popup: 'animate__animated animate__fadeInDown'
            },
            hideClass: {
                popup: 'animate__animated animate__fadeOutUp'
            }
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete-form-' + productId).submit();
                }
            });

        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>