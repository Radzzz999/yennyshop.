<?php $__env->startSection('content'); ?>
<div class="container text-white text-center" style="background: #8a2be2; min-height: 100vh; padding-top: 50px;">
    <h2>⚡ CRUD Produk Admin</h2>
    <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-success mb-3">+ Tambah Produk</a>

    <table class="table table-bordered table-dark text-white">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e($product->nama_product); ?></td>
                    <td>Rp <?php echo e(number_format($product->harga, 0, ',', '.')); ?></td>
                    <td>
                        <a href="<?php echo e(route('products.show', $product->id)); ?>" class="text-info">Lihat</a> |
                        <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="text-warning">Edit</a> |
                        <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-link text-danger p-0 m-0" onclick="return confirm('Yakin hapus?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4">Tidak ada produk.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/admin/products/index.blade.php ENDPATH**/ ?>