<?php if (isset($component)) { $__componentOriginalfa710ee477a7171fb238cadd060c5959 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfa710ee477a7171fb238cadd060c5959 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\App::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\App::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">

    <!-- Floating decorative elements -->
    <div class="floating-element">🛍️</div>
    <div class="floating-element">✨</div>
    <div class="floating-element">🎁</div>
    <div class="floating-element">💎</div>
    <div class="floating-element">🌟</div>
    <div class="floating-element">🛒</div>
    <div class="decoration-circle"></div>
    <div class="decoration-circle"></div>
    <div class="decoration-circle"></div>

    <section class="hero-section">
        <div class="hero-content">
            <h1 class="hero-title">
                <span class="shopping-emoji">🛍️</span>Selamat Datang di <span class="yennyshop-text">Yennyshop</span>
            </h1>
            <p class="hero-subtitle">
                Temukan pilihan produk terbaik, harga bersahabat, dan layanan terpercaya — semua di satu tempat.
            </p>
            <a href="<?php echo e(route('products.index')); ?>" class="btn-hero">
                Lihat Produk <i class="bi bi-arrow-right-circle"></i>
            </a>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfa710ee477a7171fb238cadd060c5959)): ?>
<?php $attributes = $__attributesOriginalfa710ee477a7171fb238cadd060c5959; ?>
<?php unset($__attributesOriginalfa710ee477a7171fb238cadd060c5959); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa710ee477a7171fb238cadd060c5959)): ?>
<?php $component = $__componentOriginalfa710ee477a7171fb238cadd060c5959; ?>
<?php unset($__componentOriginalfa710ee477a7171fb238cadd060c5959); ?>
<?php endif; ?><?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/home.blade.php ENDPATH**/ ?>