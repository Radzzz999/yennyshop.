<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>">

    <div class="container mx-auto px-4 py-12 max-w-3xl text-white">
        <h1 class="text-3xl font-bold mb-6">🛒 Keranjang Belanja</h1>

        <?php if($cart->count()): ?>
            <div class="flex flex-col gap-6">
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cart-card">
                        <img src="<?php echo e(asset('storage/' . $item->product->foto1)); ?>" alt="<?php echo e($item->product->nama_product); ?>">

                        <div class="cart-info">
                            <div class="cart-title"><?php echo e($item->product->nama_product); ?></div>
                            <div class="cart-meta">Harga: Rp <?php echo e(number_format($item->product->harga, 0, ',', '.')); ?></div>
                            <div class="cart-meta">Subtotal: Rp <?php echo e(number_format($item->product->harga * $item->quantity, 0, ',', '.')); ?></div>
                        </div>

                        
                        <div class="qty-control">
                            <form action="<?php echo e(route('cart.update', $item->product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="qty" value="<?php echo e(max(1, $item->quantity - 1)); ?>">
                                <button type="submit" class="qty-btn">−</button>
                            </form>

                            <input type="number" value="<?php echo e($item->quantity); ?>" class="qty-input" readonly>

                            <form action="<?php echo e(route('cart.update', $item->product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="qty" value="<?php echo e($item->quantity + 1); ?>">
                                <button type="submit" class="qty-btn">+</button>
                            </form>
                        </div>

                        
                        <form action="<?php echo e(route('cart.remove', $item->product->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn danger">Hapus</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-8 text-right font-semibold text-lg">
                <?php
                    $total = $cart->sum(fn($item) => $item->product->harga * $item->quantity);
                ?>
                Total: Rp <?php echo e(number_format($total, 0, ',', '.')); ?>


                <div class="text-right">
                    <a href="<?php echo e(route('payment.show')); ?>" class="checkout-link">Lanjut ke Pembayaran</a>
                </div>
            </div>
        <?php else: ?>
            <p class="text-white">Keranjang kamu masih kosong 😢</p>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/cart/index.blade.php ENDPATH**/ ?>