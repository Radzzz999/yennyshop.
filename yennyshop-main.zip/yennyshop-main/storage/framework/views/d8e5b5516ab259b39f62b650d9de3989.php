

<?php $__env->startSection('title', 'Detail Produk'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/show.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="detail-container">
    <img src="<?php echo e(asset('storage/' . $product->foto1)); ?>" class="detail-image" alt="<?php echo e($product->nama_product); ?>">

    <h2 class="detail-title"><?php echo e($product->nama_product); ?></h2>
    <div class="detail-price">Rp <?php echo e(number_format($product->harga, 0, ',', '.')); ?></div>
    <p class="detail-description"><?php echo e($product->deskripsi); ?></p>

    <div class="btn-group">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-admin">← Kembali ke Daftar Produk</a>
        <!-- <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn-admin">✏️ Edit Produk</a>
        form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus produk ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?> 
            <button type="submit" class="btn-admin">🗑️ Hapus Produk</button>-->
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/admin/products/show.blade.php ENDPATH**/ ?>