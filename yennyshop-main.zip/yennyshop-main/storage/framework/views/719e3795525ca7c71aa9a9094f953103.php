<?php $__env->startSection('title', 'Edit Produk'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/crudadmin.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="card bg-secondary text-white">
    <div class="card-header">
        <h3 class="mb-0">✏️ Edit Produk</h3>
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label for="nama_product" class="form-label">Nama Produk</label>
                <input type="text" name="nama_product" id="nama_product" class="form-control" value="<?php echo e($product->nama_product); ?>" required>
            </div>

            <div class="mb-3">
                <label for="harga" class="form-label">Harga</label>
                <input type="number" name="harga" id="harga" class="form-control" value="<?php echo e($product->harga); ?>" required>
            </div>

            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi</label>
                <textarea name="deskripsi" id="deskripsi" class="form-control" rows="4"><?php echo e($product->deskripsi); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="foto1" class="form-label">Foto Produk</label>
                <input type="file" name="foto1" id="foto1" class="form-control" accept="image/*">
                <?php if($product->foto1): ?>
                    <div class="mt-2">
                        <img src="<?php echo e(asset('storage/' . $product->foto1)); ?>" width="120" class="img-thumbnail">
                    </div>
                <?php endif; ?>
            </div>

            <div class="d-flex justify-content-between mt-4">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-light">← Kembali</a>
                <button type="submit" class="btn btn-primary">💾 Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>