<!DOCTYPE html>
<html>
<head><title>Yennyshop</title></head>
<body>
    <?php echo e($slot); ?>

</body>
</html><?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>