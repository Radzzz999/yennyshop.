<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Yennyshop')); ?></title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=poppins:400,500,600&display=swap" rel="stylesheet" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        body {
            background: linear-gradient(to bottom right, #5b2c94, #a86cc1);
            font-family: 'Poppins', sans-serif;
            color: white;
        }

        nav.appbar {
            background-color: #4B1C89;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        nav.appbar a {
            color: white;
            text-decoration: none;
            margin-left: 1.25rem;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        nav.appbar a:hover,
        .logout-btn:hover {
            color: #fbd6ff;
        }

        .logout-btn {
            background: transparent;
            border: none;
            color: #f093fb;
            font-weight: 500;
            cursor: pointer;
            padding: 0;
        }
    </style>
</head>
<body>
    
    <nav class="appbar">
        <div class="flex items-center gap-4">
            <div class="text-xl font-bold">🛍️ Yennyshop</div>
            <a href="<?php echo e(route('home')); ?>">Beranda</a>
            <a href="<?php echo e(route('products.index')); ?>">Produk</a>
            <a href="<?php echo e(route('cart.index')); ?>">Keranjang</a>
        </div>
        <div class="flex items-center gap-4">
            <?php if(auth()->guard()->check()): ?>
                <span class="font-medium"><?php echo e(Auth::user()->name); ?></span>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="logout-btn">Keluar</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>
                <a href="<?php echo e(route('register')); ?>">Daftar</a>
            <?php endif; ?>
        </div>
    </nav>

    
    <main class="min-h-screen">
        <?php echo e($slot); ?>

    </main>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
</body>
</html><?php /**PATH D:\KULIAH SEMESTER 6\PWF\yennyshop final\yennyshop-main\yennyshop-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>